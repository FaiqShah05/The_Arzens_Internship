"""
validator.py
------------
Simple CSV schema validator for THE ARZENS lab automation intern assignment.

What it does:
- Reads a CSV file and checks each row against a schema (column names,
  required columns, and expected data types).
- Skips/rejects rows that are malformed (missing required field, wrong type,
  or wrong number of columns) without crashing the whole run.
- Logs every rejection to validation_errors.log using the `logging` module,
  including the row number and the field that failed -- but NEVER logs the
  actual value of sensitive-looking fields (passwords, tokens, national IDs,
  etc.). Only the field name and the type of error is recorded.
- Ships with a small synthetic sample_data.csv (created automatically if it
  doesn't already exist) so the script can be run end-to-end out of the box.

Run it directly:
    python validator.py
"""

import csv
import logging
import os

# ---------------------------------------------------------------------------
# Schema definition
# ---------------------------------------------------------------------------
# Each column maps to an expected Python type. Columns marked required=True
# must be present and non-empty in every row.
SCHEMA = {
    "employee_id":   {"type": int,   "required": True},
    "name":          {"type": str,   "required": True},
    "department":    {"type": str,   "required": True},
    "age":           {"type": int,   "required": True},
    "password_hash": {"type": str,   "required": False},  # sensitive field
}

EXPECTED_COLUMN_COUNT = len(SCHEMA)

# Any column name in this set is treated as sensitive: its value is never
# printed or logged, even when it fails validation.
SENSITIVE_FIELDS = {"password_hash", "token", "ssn", "cnic", "national_id"}

LOG_FILE = "validation_errors.log"
SAMPLE_CSV = "sample_data.csv"


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------
def setup_logging():
    logging.basicConfig(
        filename=LOG_FILE,
        filemode="w",
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
    )


def log_rejection(row_number, field, error_type):
    """Log a rejected row without ever writing the actual field value."""
    logging.info("Row %d rejected | field=%s | error=%s", row_number, field, error_type)


# ---------------------------------------------------------------------------
# Sample data generation (only runs if sample_data.csv is missing)
# ---------------------------------------------------------------------------
def create_sample_csv(path):
    rows = [
        ["employee_id", "name", "department", "age", "password_hash"],
        ["101", "Ayesha Khan", "Engineering", "24", "9f8c1a2b"],   # valid
        ["102", "Bilal Ahmed", "Sales", "29", "aa11bb22"],          # valid
        ["", "Sara Malik", "Marketing", "27", "cc33dd44"],          # missing required field (employee_id)
        ["104", "Usman Tariq", "Engineering", "not_a_number", "ee55ff66"],  # wrong type (age)
        ["105", "Hina Riaz", "HR", "31"],                            # wrong number of columns
        ["106", "Zain Abbas", "Finance", "35", "SuperSecretPass123"],  # sensitive-looking value, still valid row
    ]
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(rows)


# ---------------------------------------------------------------------------
# Validation logic
# ---------------------------------------------------------------------------
def validate_row(row, header, row_number):
    """
    Validates a single row (a list of string values) against SCHEMA.
    Returns True if the row is valid, False if it was rejected.
    """
    # 1. Check column count
    if len(row) != EXPECTED_COLUMN_COUNT:
        log_rejection(row_number, "row", "unexpected_column_count")
        return False

    record = dict(zip(header, row))

    for field, rules in SCHEMA.items():
        value = record.get(field, "")

        # 2. Required field check
        if rules["required"] and (value is None or str(value).strip() == ""):
            log_rejection(row_number, field, "missing_required_field")
            return False

        # Skip type check for empty optional fields
        if not rules["required"] and str(value).strip() == "":
            continue

        # 3. Type check
        expected_type = rules["type"]
        if expected_type is int:
            if not str(value).strip().lstrip("-").isdigit():
                log_rejection(row_number, field, "invalid_type_expected_int")
                return False
        elif expected_type is str:
            if not isinstance(value, str) or value.strip() == "":
                log_rejection(row_number, field, "invalid_type_expected_str")
                return False

    return True


def run_validator(csv_path):
    valid_count = 0
    rejected_count = 0

    with open(csv_path, newline="") as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            print("CSV file is empty.")
            return 0, 0

        for row_number, row in enumerate(reader, start=2):  # row 1 is the header
            try:
                if validate_row(row, header, row_number):
                    valid_count += 1
                else:
                    rejected_count += 1
            except Exception:
                # Never let one bad row crash the whole run.
                log_rejection(row_number, "unknown", "unexpected_processing_error")
                rejected_count += 1

    return valid_count, rejected_count


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    setup_logging()

    if not os.path.exists(SAMPLE_CSV):
        create_sample_csv(SAMPLE_CSV)

    valid, rejected = run_validator(SAMPLE_CSV)

    print("Validation complete.")
    print(f"Valid rows:    {valid}")
    print(f"Rejected rows: {rejected}")
    print(f"See '{LOG_FILE}' for details on rejected rows (no sensitive values are logged).")
