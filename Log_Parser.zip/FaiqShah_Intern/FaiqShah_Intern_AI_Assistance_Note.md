# AI Assistance Note

I used two AI tools while completing this assignment: Claude (Anthropic) and
GitHub Copilot.

**Claude (Anthropic) — used for brainstorming and understanding:**
- Explaining the assignment requirements in plain language, since the task
  manual was long and I wasn't sure what was actually being asked at first.
- Helping me understand concepts I was confused about (e.g. `argparse`,
  `datetime.strptime`, how `unittest` scenarios should be structured).
- Drafting an initial version of `log_parser.py`, `test_parser.py`, and the
  Task 1 comparison note as a starting point to learn from and revise.
- Generating sample log data and running the parser to produce
  `output_parsed.csv`.

**GitHub Copilot — used for coding assistance:**
- [Fill in: e.g. inline autocomplete/suggestions while writing or editing
  the parser and test code, small syntax fixes, docstring suggestions, etc.]

**What I did myself:**
- Reviewed and understood the parsing logic, error handling, and test
  scenarios before submitting.
- [Fill in: any edits you made, sections you rewrote, or code you changed
  after reviewing it.]
- Verified the tests pass on my own machine and understand what each one
  checks.

I take responsibility for the accuracy and originality of the final
submission, per the assignment's academic integrity policy.
