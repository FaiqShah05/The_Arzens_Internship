#!/usr/bin/env python3
"""
test_parser.py
--------------
Unit tests for log_parser.py.

How to run:
    python test_parser.py
    (or, if you have pytest installed)
    pytest test_parser.py -v

Each test checks ONE scenario from the assignment brief:
    1. Valid input               -> test_valid_input_is_parsed_correctly
    2. Missing fields            -> test_missing_fields_are_skipped
    3. Malformed timestamps      -> test_malformed_timestamp_is_skipped
    4. Empty file                -> test_empty_file_produces_zero_counts
    5. Duplicate records         -> test_duplicates_are_preserved
    6. Unsafe output path        -> test_unsafe_output_path_fails_gracefully
    (plus) --dry-run behavior    -> test_dry_run_does_not_write_file
"""

import csv
import io
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

# Make sure we're importing the parser from this same folder,
# regardless of where the tests are run from.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import FaiqShah_Intern_log_parser as log_parser  # noqa: E402


class LogParserTestCase(unittest.TestCase):
    """
    setUp() runs before every single test, tearDown() runs after --
    they give each test a clean, isolated temporary folder to work in,
    so tests never interfere with each other or with real project files.
    """

    def setUp(self):
        self.test_dir = tempfile.mkdtemp(prefix="log_parser_test_")

    def tearDown(self):
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def _write_log_file(self, filename: str, lines) -> str:
        """Helper: write a list of lines into a log file and return its path."""
        path = os.path.join(self.test_dir, filename)
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
            if lines:
                f.write("\n")
        return path

    # ------------------------------------------------------------------
    # Scenario 1: Valid input
    # ------------------------------------------------------------------
    def test_valid_input_is_parsed_correctly(self):
        lines = [
            "2026-07-15T10:23:45Z,192.168.1.100,LOGIN,SUCCESS",
            "2026-07-15T10:24:12Z,192.168.1.101,LOGOUT,SUCCESS",
        ]
        input_path = self._write_log_file("valid.txt", lines)

        rows, total, skipped = log_parser.parse_log_file(input_path)

        self.assertEqual(total, 2)
        self.assertEqual(skipped, 0)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["source_ip"], "192.168.1.100")
        self.assertEqual(rows[0]["event_type"], "LOGIN")
        self.assertEqual(rows[0]["status"], "SUCCESS")
        # Timestamp should be normalized (ISO 8601), not just copied verbatim.
        self.assertTrue(rows[0]["timestamp"].startswith("2026-07-15T10:23:45"))

    # ------------------------------------------------------------------
    # Scenario 2: Missing fields
    # ------------------------------------------------------------------
    def test_missing_fields_are_skipped(self):
        lines = [
            "2026-07-15T10:23:45Z,192.168.1.100,LOGIN,SUCCESS",   # valid
            "2026-07-15T10:24:12Z,192.168.1.101,LOGOUT",           # only 3 fields
        ]
        input_path = self._write_log_file("missing_fields.txt", lines)

        rows, total, skipped = log_parser.parse_log_file(input_path)

        self.assertEqual(total, 2)
        self.assertEqual(len(rows), 1)   # only the valid line got through
        self.assertEqual(skipped, 1)     # the broken line was skipped, not crashed on

    # ------------------------------------------------------------------
    # Scenario 3: Malformed timestamps
    # ------------------------------------------------------------------
    def test_malformed_timestamp_is_skipped(self):
        lines = [
            "2026-07-15T10:23:45Z,192.168.1.100,LOGIN,SUCCESS",  # valid
            "NOT-A-TIMESTAMP,192.168.1.101,LOGOUT,SUCCESS",       # bad timestamp
        ]
        input_path = self._write_log_file("bad_timestamp.txt", lines)

        rows, total, skipped = log_parser.parse_log_file(input_path)

        self.assertEqual(total, 2)
        self.assertEqual(len(rows), 1)
        self.assertEqual(skipped, 1)

    # ------------------------------------------------------------------
    # Scenario 4: Empty file
    # ------------------------------------------------------------------
    def test_empty_file_produces_zero_counts(self):
        input_path = self._write_log_file("empty.txt", [])

        rows, total, skipped = log_parser.parse_log_file(input_path)

        self.assertEqual(total, 0)
        self.assertEqual(skipped, 0)
        self.assertEqual(rows, [])

    # ------------------------------------------------------------------
    # Scenario 5: Duplicate records
    # ------------------------------------------------------------------
    def test_duplicates_are_preserved(self):
        line = "2026-07-15T10:23:45Z,192.168.1.100,LOGIN,SUCCESS"
        lines = [line, line, line]  # same line 3 times on purpose
        input_path = self._write_log_file("duplicates.txt", lines)

        rows, total, skipped = log_parser.parse_log_file(input_path)

        # All 3 duplicates should show up in the output -- the parser
        # must NOT silently deduplicate them.
        self.assertEqual(total, 3)
        self.assertEqual(len(rows), 3)
        self.assertEqual(skipped, 0)

    # ------------------------------------------------------------------
    # Scenario 6: Unsafe output path (directory that doesn't exist)
    # ------------------------------------------------------------------
    def test_unsafe_output_path_fails_gracefully(self):
        rows = [{
            "timestamp": "2026-07-15T10:23:45Z",
            "source_ip": "192.168.1.100",
            "event_type": "LOGIN",
            "status": "SUCCESS",
        }]
        bad_output_path = os.path.join(
            self.test_dir, "this_folder_does_not_exist", "out.csv"
        )

        # write_csv should raise a normal, catchable error (FileNotFoundError)
        # rather than corrupting data or hanging -- main() turns this into
        # a friendly message, which we exercise below via the CLI.
        with self.assertRaises(FileNotFoundError):
            log_parser.write_csv(rows, bad_output_path)

    def test_cli_reports_friendly_error_for_unsafe_output_path(self):
        """
        End-to-end check: running the script via the command line against
        a non-existent output directory should exit with an error message,
        not a raw Python traceback.
        """
        input_path = self._write_log_file(
            "valid_for_cli.txt",
            ["2026-07-15T10:23:45Z,192.168.1.100,LOGIN,SUCCESS"],
        )
        bad_output_path = os.path.join(
            self.test_dir, "missing_folder", "out.csv"
        )

        result = subprocess.run(
            [sys.executable, _parser_script_path(), input_path,
             "-o", bad_output_path],
            capture_output=True, text=True,
        )

        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Error", result.stderr)

    # ------------------------------------------------------------------
    # Extra: --dry-run behavior
    # ------------------------------------------------------------------
    def test_dry_run_does_not_write_file(self):
        input_path = self._write_log_file(
            "dry_run.txt",
            ["2026-07-15T10:23:45Z,192.168.1.100,LOGIN,SUCCESS"],
        )
        output_path = os.path.join(self.test_dir, "should_not_exist.csv")

        result = subprocess.run(
            [sys.executable, _parser_script_path(), input_path,
             "-o", output_path, "--dry-run"],
            capture_output=True, text=True,
        )

        self.assertEqual(result.returncode, 0)
        self.assertIn("DRY RUN", result.stdout)
        self.assertFalse(
            os.path.exists(output_path),
            "Dry run should NOT create the output file.",
        )


def _parser_script_path() -> str:
    """Path to FaiqShah_Intern_log_parser.py, used for the subprocess/CLI-level tests."""
    return os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "FaiqShah_Intern_log_parser.py"
    )


if __name__ == "__main__":
    unittest.main(verbosity=2)
