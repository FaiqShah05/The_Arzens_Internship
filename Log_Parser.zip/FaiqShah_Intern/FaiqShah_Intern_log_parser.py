#!/usr/bin/env python3
"""
log_parser.py
--------------
A simple command-line security log parser.

What it does:
    - Reads a plain-text log file, one event per line.
    - Each line is expected in the format:
          timestamp,source_ip,event_type,status
      Example:
          2026-07-15T10:23:45Z,192.168.1.100,LOGIN,SUCCESS
    - Extracts timestamp, source_ip, event_type, and status.
    - Normalizes the timestamp to ISO 8601 format.
    - Skips malformed lines instead of crashing, and counts them.
    - Writes the successfully parsed lines to a CSV file.
    - Prints a short summary to the console.
    - Supports a --dry-run flag that shows what WOULD happen,
      without actually writing the output CSV.

Usage:
    python log_parser.py sample_logs.txt
    python log_parser.py sample_logs.txt -o my_output.csv
    python log_parser.py sample_logs.txt --dry-run
"""

import argparse
import csv
import os
import sys
from datetime import datetime

# The log format we expect on each line, in order.
FIELD_NAMES = ["timestamp", "source_ip", "event_type", "status"]

# We try these timestamp formats when reading a log line.
# Add more formats here if your logs use a different style.
TIMESTAMP_FORMATS = [
    "%Y-%m-%dT%H:%M:%SZ",   # e.g. 2026-07-15T10:23:45Z
    "%Y-%m-%d %H:%M:%S",    # e.g. 2026-07-15 10:23:45
]


def normalize_timestamp(raw_timestamp: str) -> str:
    """
    Try to parse the raw timestamp string using the known formats
    and return it in a standard ISO 8601 string.

    Raises ValueError if none of the known formats match.
    """
    for fmt in TIMESTAMP_FORMATS:
        try:
            dt = datetime.strptime(raw_timestamp, fmt)
            return dt.isoformat() + ("Z" if fmt.endswith("Z") else "")
        except ValueError:
            continue
    # If we get here, nothing matched.
    raise ValueError(f"Unrecognized timestamp format: {raw_timestamp!r}")


def parse_line(line: str):
    """
    Parse a single log line into a dictionary of fields.

    Returns a dict like:
        {"timestamp": ..., "source_ip": ..., "event_type": ..., "status": ...}

    Raises ValueError if the line is malformed (wrong number of fields
    or a bad timestamp), so the caller can catch it and skip the line.
    """
    line = line.strip()
    if not line:
        raise ValueError("Empty line")

    parts = [p.strip() for p in line.split(",")]

    if len(parts) != len(FIELD_NAMES):
        raise ValueError(
            f"Expected {len(FIELD_NAMES)} fields, got {len(parts)}: {line!r}"
        )

    raw_timestamp, source_ip, event_type, status = parts

    # This will raise ValueError if the timestamp can't be parsed,
    # which is exactly what we want -- the caller treats it as malformed.
    timestamp = normalize_timestamp(raw_timestamp)

    if not source_ip or not event_type or not status:
        raise ValueError(f"Missing field(s) in line: {line!r}")

    return {
        "timestamp": timestamp,
        "source_ip": source_ip,
        "event_type": event_type,
        "status": status,
    }


def parse_log_file(input_path: str):
    """
    Read the log file at input_path and parse every line.

    Returns a tuple: (parsed_rows, total_lines, skipped_count)
    parsed_rows is a list of dicts (see parse_line).
    Malformed lines are skipped, not raised, so one bad line never
    crashes the whole run.
    """
    parsed_rows = []
    total_lines = 0
    skipped_count = 0

    with open(input_path, "r", encoding="utf-8") as f:
        for raw_line in f:
            # Ignore fully blank lines without counting them as "skipped".
            if not raw_line.strip():
                continue

            total_lines += 1
            try:
                row = parse_line(raw_line)
                parsed_rows.append(row)
            except ValueError:
                # Malformed line (wrong field count or bad timestamp).
                # We deliberately do NOT crash here -- we just count it.
                skipped_count += 1

    return parsed_rows, total_lines, skipped_count


def write_csv(rows, output_path: str):
    """Write the parsed rows to a CSV file with headers."""
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELD_NAMES)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Parse a plain-text security log file into a CSV."
    )
    parser.add_argument(
        "input_file",
        help="Path to the input log file (one event per line).",
    )
    parser.add_argument(
        "-o", "--output",
        default="output_parsed.csv",
        help="Path to the output CSV file (default: output_parsed.csv).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would happen, but do not write the output file.",
    )
    return parser


def main():
    args = build_arg_parser().parse_args()

    # --- Validate the input file exists before doing anything else. ---
    if not os.path.isfile(args.input_file):
        print(f"Error: input file not found: {args.input_file}", file=sys.stderr)
        sys.exit(1)

    # --- Parse the file. ---
    try:
        rows, total_lines, skipped_count = parse_log_file(args.input_file)
    except PermissionError:
        print(f"Error: permission denied reading {args.input_file}", file=sys.stderr)
        sys.exit(1)

    successful = len(rows)

    # --- Dry run: report what would happen, but don't write anything. ---
    if args.dry_run:
        print("[DRY RUN] No output file was written.")
        print(f"[DRY RUN] Would write {successful} row(s) to: {args.output}")
        print(f"Total lines processed: {total_lines}")
        print(f"Successful extractions: {successful}")
        print(f"Skipped (malformed) lines: {skipped_count}")
        return

    # --- Real run: write the CSV, handling permission errors gracefully. ---
    try:
        write_csv(rows, args.output)
    except PermissionError:
        print(f"Error: permission denied writing to {args.output}", file=sys.stderr)
        sys.exit(1)
    except FileNotFoundError:
        # Happens if the output directory doesn't exist.
        print(
            f"Error: could not write to '{args.output}' "
            f"(the destination folder may not exist).",
            file=sys.stderr,
        )
        sys.exit(1)

    print(f"Output written to: {args.output}")
    print(f"Total lines processed: {total_lines}")
    print(f"Successful extractions: {successful}")
    print(f"Skipped (malformed) lines: {skipped_count}")


if __name__ == "__main__":
    main()
