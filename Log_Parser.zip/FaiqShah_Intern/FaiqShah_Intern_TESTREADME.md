# Test Suite Documentation

## How to run

```bash
python test_parser.py
```

or, if pytest is installed:

```bash
pytest test_parser.py -v
```

## What each test verifies

| Test name | Scenario | What it checks |
|---|---|---|
| `test_valid_input_is_parsed_correctly` | 1. Valid input | A correctly formatted log file is parsed into the right number of rows, with correct fields and a normalized timestamp. |
| `test_missing_fields_are_skipped` | 2. Missing fields | A line with a missing field (only 3 values instead of 4) is skipped and counted, not crashed on. |
| `test_malformed_timestamp_is_skipped` | 3. Malformed timestamps | A line with an unreadable timestamp is skipped gracefully, with an accurate skip count. |
| `test_empty_file_produces_zero_counts` | 4. Empty file | A completely empty input file produces 0 total, 0 skipped, and an empty result list. |
| `test_duplicates_are_preserved` | 5. Duplicate records | The same log line repeated 3 times results in 3 rows in the output — duplicates are NOT removed. |
| `test_unsafe_output_path_fails_gracefully` | 6. Unsafe output path | Writing to a folder that doesn't exist raises a normal, catchable error instead of corrupting data. |
| `test_cli_reports_friendly_error_for_unsafe_output_path` | 6. Unsafe output path (CLI) | Running the script from the command line against a bad output path exits with a clear error message, not a raw traceback. |
| `test_dry_run_does_not_write_file` | Extra: --dry-run | Running with `--dry-run` prints a dry-run summary and confirms no output file is actually created. |

## Test folder contents (`test_sample_logs/`)

These files mirror the scenarios above and can be used to manually re-check
the parser's behavior with the CLI directly:

- `FaiqShah_Intern_valid.txt` — two well-formed log lines
- `FaiqShah_Intern_missing_fields.txt` — one valid line, one line missing a field
- `FaiqShah_Intern_bad_timestamp.txt` — one valid line, one line with an unreadable timestamp
- `FaiqShah_Intern_empty.txt` — a completely empty file
- `FaiqShah_Intern_duplicates.txt` — the same valid line repeated three times

Example manual check:

```bash
python log_parser.py test_sample_logs/FaiqShah_Intern_duplicates.txt -o /tmp/dup_out.csv
```
