# Log Parser

A simple command-line tool that reads a plain-text security log file and
converts it into a clean CSV file.

## What it does

- Reads a log file where each line looks like:
  `2026-07-15T10:23:45Z,192.168.1.100,LOGIN,SUCCESS`
- Extracts 4 fields: `timestamp`, `source_ip`, `event_type`, `status`
- Normalizes the timestamp to ISO 8601 format
- Skips malformed / broken lines instead of crashing, and counts them
- Writes the good rows to a CSV file with headers
- Prints a summary (total lines, successful, skipped) to the console

## Requirements

- Python 3.8+ (no external libraries needed — only the standard library)

## Usage

Basic run (writes to `FaiqShah_Intern_output_parsed.csv` by default):

```bash
python FaiqShah_Intern_log_parser.py FaiqShah_Intern_sample_logs.txt
```

Choose a custom output file:

```bash
python FaiqShah_Intern_log_parser.py FaiqShah_Intern_sample_logs.txt -o my_output.csv
```

Preview what would happen without writing any file:

```bash
python FaiqShah_Intern_log_parser.py FaiqShah_Intern_sample_logs.txt --dry-run
```

## Files in this folder

| File                 | Purpose                                      |
|----------------------|-----------------------------------------------|
| `FaiqShah_Intern_log_parser.py`      | Main script                                   |
| `FaiqShah_Intern_sample_logs.txt`    | Example input log file (includes bad lines)   |
| `FaiqShah_Intern_output_parsed.csv`  | Example output after running the parser       |

## Error handling

- If the input file doesn't exist, the script prints a clear error and exits
  (it does not crash with a traceback).
- If a log line has the wrong number of fields or an unreadable timestamp,
  that line is skipped and counted — the rest of the file still processes.
- If the output file can't be written (bad permissions or missing folder),
  the script prints a helpful error instead of crashing.
