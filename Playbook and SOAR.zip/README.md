# Phishing Response Playbook

A single-file playbook that takes a reported phishing email, pulls out the
indicators, checks them against local blacklists (and VirusTotal if you
give it a key), scores the risk, and decides what to do about it.

## Setup

```bash
pip install requests pyyaml python-dotenv
```

No API key is required to run it. If `virustotal_api_key` in `config.yaml`
is left blank, URL checks fall back to a small set of offline heuristics
(looks for words like "evil", "phish", "login" etc. in the URL) so the
playbook still works without internet access.

## Running it

```bash
# from a JSON file
python ArzensIntern_Faiq_phishing_playbook.py --input-file sample_email.json

# from CLI flags
python ArzensIntern_Faiq_phishing_playbook.py --sender security@paypa1.com \
    --subject "Urgent: Verify Your Account" \
    --body "Click here: http://evil-site.com/login"

# test without taking real action
python ArzensIntern_Faiq_phishing_playbook.py --input-file sample_email.json --dry-run

# undo the last quarantine
python ArzensIntern_Faiq_phishing_playbook.py --rollback
```

## How the scoring works

| Signal | Points |
|---|---|
| Sender domain on blacklist / looks like a typosquat | +40 |
| A URL flagged malicious | +30 |
| Attachment hash matches known malware | +50 |
| Each suspicious keyword in subject/body | +10 |

Score is capped at 100.

- **>= 70 (HIGH):** quarantine the email, block the sender, notify the security team
- **40-69 (MEDIUM):** hold for analyst review, notify the user
- **< 40 (LOW):** log it and deliver with a warning banner

## Files

- `ArzensIntern_Faiq_phishing_playbook.py` - the playbook itself
- `config.yaml` - thresholds, notify address, blacklist/hash file paths
- `blacklist_domains.txt` / `malware_hashes.txt` - sample threat intel, one entry per line
- `sample_email.json` - example input matching the assignment spec
- `sample_output.txt` - what a dry-run against the sample input looks like

## Notes on the implementation

- Quarantine "state" is just a JSON file (`quarantine_state.json`) recording
  what was quarantined and when. `--rollback` reads it, prints a restore
  message, and deletes it. In a real environment this would call back into
  the mail server API instead.
- Every run writes its own timestamped log file (`playbook_run_<id>.log`)
  plus a JSON report (`report_<id>.json`) so a specific run can be audited
  later without digging through one giant log.
- If a reputation check throws (e.g. VirusTotal times out), the playbook
  logs the failure and keeps going with whatever data it has rather than
  crashing the whole run - that's the "continue on partial failure"
  requirement from the assignment.
- The typosquat check is intentionally simple (single-character diff /
  common leet-speak swap against a short list of well known domains). It's
  good enough to catch `paypa1.com` but it's not a real similarity/edit
  distance algorithm - noted as a limitation rather than pretending it's
  more robust than it is.
