#!/usr/bin/env python3
"""
playbook_manager.py

Keeps a registry of playbooks, runs them on demand or on a schedule,
tracks execution history, and reports on whether each playbook is
configured correctly (health check).

Usage:
    python playbook_manager.py --list
    python playbook_manager.py --run phishing_playbook --input sample_email.json
    python playbook_manager.py --schedule phishing_playbook --interval hourly
    python playbook_manager.py --health-check
    python playbook_manager.py --history --last 10
"""

import argparse
import json
import os
import subprocess
import sys
import time
from datetime import datetime

try:
    import yaml
except ImportError:
    yaml = None

try:
    import schedule as schedule_lib
except ImportError:
    schedule_lib = None


REGISTRY_FILE = "playbook_registry.json"
EXECUTIONS_FILE = "executions.json"
PLAYBOOK_DIR = "sample_playbooks"


def load_json(path, default):
    if not os.path.exists(path):
        return default
    with open(path) as f:
        return json.load(f)


def save_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def load_registry():
    return load_json(REGISTRY_FILE, {"playbooks": []})


def load_executions():
    return load_json(EXECUTIONS_FILE, [])


def find_playbook(registry, name):
    for pb in registry["playbooks"]:
        if pb["name"] == name:
            return pb
    return None


# ---------------------------------------------------------------------------
# listing
# ---------------------------------------------------------------------------

def cmd_list(registry):
    print("Available Playbooks:")
    for i, pb in enumerate(registry["playbooks"], 1):
        status = "ENABLED " if pb.get("enabled", True) else "DISABLED"
        print(f"  [{i}] {pb['name']:<20} {status} - {pb['description']}")


# ---------------------------------------------------------------------------
# running a playbook
# ---------------------------------------------------------------------------

def run_playbook(registry, name, extra_args=None):
    pb = find_playbook(registry, name)
    if pb is None:
        print(f"Unknown playbook: {name}")
        return None

    if not pb.get("enabled", True):
        print(f"Playbook '{name}' is disabled, skipping.")
        return None

    script_path = pb["script"]
    if not os.path.exists(script_path):
        print(f"Playbook script not found at {script_path}")
        record_execution(name, "FAILED", 0, "script not found")
        return None

    cmd = [sys.executable, script_path]
    if extra_args:
        cmd += extra_args

    start = datetime.now()
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        duration = (datetime.now() - start).total_seconds()
        status = "SUCCESS" if result.returncode == 0 else "FAILED"
        summary = result.stdout.strip().splitlines()[-1] if result.stdout.strip() else result.stderr.strip()[:120]
        record_execution(name, status, duration, summary)

        if status == "FAILED":
            notify("playbook_failed", name=name, error=summary)

        print(f"[{start.strftime('%Y-%m-%d %H:%M:%S')}] {name:<20} {status}  {summary}")
        return status
    except subprocess.TimeoutExpired:
        duration = (datetime.now() - start).total_seconds()
        record_execution(name, "FAILED", duration, "execution timed out")
        notify("playbook_failed", name=name, error="timeout")
        print(f"Playbook '{name}' timed out.")
        return "FAILED"


def record_execution(name, status, duration, summary):
    executions = load_executions()
    executions.append({
        "playbook": name,
        "timestamp": datetime.now().isoformat(),
        "duration_seconds": round(duration, 2),
        "status": status,
        "summary": summary,
    })
    save_json(EXECUTIONS_FILE, executions)


def cmd_history(last_n):
    executions = load_executions()
    recent = executions[-last_n:][::-1]
    print(f"Execution History (Last {len(recent)}):")
    for run in recent:
        ts = run["timestamp"].replace("T", " ")[:19]
        print(f"  [{ts}] {run['playbook']:<20} {run['status']:<8} {run['summary']}")


# ---------------------------------------------------------------------------
# health checks
# ---------------------------------------------------------------------------

def check_playbook_health(pb):
    issues = []

    if not os.path.exists(pb["script"]):
        issues.append("script missing")
        return issues

    config_path = pb.get("config", "config.yaml")
    if not os.path.exists(config_path):
        issues.append("config missing")
    elif yaml is not None:
        try:
            with open(config_path) as f:
                yaml.safe_load(f)
        except Exception:
            issues.append("config invalid")

    for dep_file in pb.get("required_files", []):
        if not os.path.exists(dep_file):
            issues.append(f"missing {dep_file}")

    return issues


def cmd_health_check(registry):
    print("Health Status:")
    report = []
    for pb in registry["playbooks"]:
        issues = check_playbook_health(pb)
        if issues:
            print(f"  [!] {pb['name']:<20} {', '.join(issues)}")
        else:
            print(f"  [OK] {pb['name']:<20} Healthy")
        report.append({"playbook": pb["name"], "issues": issues, "checked_at": datetime.now().isoformat()})
    save_json("health_report.json", report)


# ---------------------------------------------------------------------------
# notifications
# ---------------------------------------------------------------------------

def notify(event_type, **kwargs):
    """Writes a notification to a local outbox file. In production this
    would hit an email/Slack webhook - kept local here so the assignment
    doesn't depend on real credentials to demonstrate the behaviour."""
    outbox = load_json("notifications_outbox.json", [])
    outbox.append({"event": event_type, "timestamp": datetime.now().isoformat(), **kwargs})
    save_json("notifications_outbox.json", outbox)


def daily_summary(registry):
    executions = load_executions()
    today = datetime.now().date().isoformat()
    todays_runs = [e for e in executions if e["timestamp"].startswith(today)]
    summary = {
        "date": today,
        "total_runs": len(todays_runs),
        "success": sum(1 for e in todays_runs if e["status"] == "SUCCESS"),
        "failed": sum(1 for e in todays_runs if e["status"] == "FAILED"),
    }
    notify("daily_summary", **summary)
    print(f"Daily summary: {summary}")


# ---------------------------------------------------------------------------
# scheduling
# ---------------------------------------------------------------------------

def cmd_schedule(registry, name, interval):
    if schedule_lib is None:
        print("The 'schedule' library isn't installed. Run: pip install schedule")
        return

    pb = find_playbook(registry, name)
    if pb is None:
        print(f"Unknown playbook: {name}")
        return

    job = lambda: run_playbook(registry, name)

    if interval == "hourly":
        schedule_lib.every().hour.do(job)
    elif interval == "daily":
        schedule_lib.every().day.at("09:00").do(job)
    else:
        print(f"Unsupported interval: {interval} (use hourly or daily)")
        return

    print(f"Scheduled '{name}' to run {interval}. Press Ctrl+C to stop.")
    try:
        while True:
            schedule_lib.run_pending()
            time.sleep(30)
    except KeyboardInterrupt:
        print("\nScheduler stopped.")


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def parse_args():
    p = argparse.ArgumentParser(description="Playbook manager and scheduler")
    p.add_argument("--list", action="store_true")
    p.add_argument("--run", metavar="PLAYBOOK_NAME")
    p.add_argument("--input", help="input file to pass to the playbook being run")
    p.add_argument("--schedule", metavar="PLAYBOOK_NAME")
    p.add_argument("--interval", default="hourly")
    p.add_argument("--health-check", action="store_true")
    p.add_argument("--history", action="store_true")
    p.add_argument("--last", type=int, default=10)
    p.add_argument("--daily-summary", action="store_true")
    return p.parse_args()


def main():
    args = parse_args()
    registry = load_registry()

    print("+" + "=" * 58 + "+")
    print("|               PLAYBOOK MANAGER v1.0                     |")
    print("+" + "=" * 58 + "+\n")

    if args.list:
        cmd_list(registry)
    elif args.run:
        extra = ["--input-file", args.input] if args.input else []
        run_playbook(registry, args.run, extra)
    elif args.schedule:
        cmd_schedule(registry, args.schedule, args.interval)
    elif args.health_check:
        cmd_health_check(registry)
    elif args.history:
        cmd_history(args.last)
    elif args.daily_summary:
        daily_summary(registry)
    else:
        cmd_list(registry)
        print()
        cmd_history(5)
        print()
        cmd_health_check(registry)


if __name__ == "__main__":
    main()
