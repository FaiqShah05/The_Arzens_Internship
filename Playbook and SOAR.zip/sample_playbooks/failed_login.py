#!/usr/bin/env python3
"""
failed_login.py

Brute-force / failed login anomaly playbook. This one is left disabled
in the registry and without a config.yaml on purpose - it's used in the
README/health-check demo to show what an unhealthy playbook looks like
in the manager's output, which is also realistic: not every playbook in
a SOC's library is finished and production-ready at the same time.
"""

import argparse
import sys


def parse_args():
    p = argparse.ArgumentParser(description="Failed login anomaly playbook")
    p.add_argument("--ip", required=False)
    p.add_argument("--attempts", type=int, default=0)
    return p.parse_args()


def main():
    args = parse_args()
    if not args.ip:
        print("Missing --ip, nothing to check.")
        sys.exit(1)

    if args.attempts >= 10:
        print(f"{args.ip}: confirmed brute force -> blocking IP")
    else:
        print(f"{args.ip}: suspicious -> requiring MFA")


if __name__ == "__main__":
    main()
