# Playbook Manager

Registers, runs, schedules and health-checks the playbooks in
`sample_playbooks/`. Think of it as a very small SOAR "orchestration layer"
sitting on top of the individual playbook scripts.

## Setup

```bash
pip install schedule pyyaml
```

`schedule` is only needed for `--schedule`; the other commands work
without it.

## Commands

```bash
# see what's registered
python ArzensIntern_Faiq_playbook_manager.py --list

# run one playbook right now
python ArzensIntern_Faiq_playbook_manager.py --run phishing_playbook --input sample_email.json

# put a playbook on a recurring schedule (blocks the terminal, Ctrl+C to stop)
python ArzensIntern_Faiq_playbook_manager.py --schedule phishing_playbook --interval hourly

# check that every registered playbook has what it needs to run
python ArzensIntern_Faiq_playbook_manager.py --health-check

# see recent runs
python ArzensIntern_Faiq_playbook_manager.py --history --last 10
```

Running with no flags at all does list + recent history + health check in
one go, which is what I use day-to-day.

## How it's put together

- `playbook_registry.json` is the source of truth for what playbooks exist,
  where their script lives, which config they need, and whether they're
  turned on. Adding a new playbook is just adding an entry here.
- Each run shells out to the playbook script with `subprocess.run`, so any
  playbook that behaves like a normal CLI tool (accepts args, prints
  output, exits 0/non-zero) can be registered - it doesn't need to import
  anything from the manager.
- Every run gets appended to `executions.json`. That's the full history;
  `--history` just reads the tail of it.
- `--health-check` checks three things per playbook: does the script file
  exist, does its config file parse as valid YAML, and are any
  `required_files` present. `failed_login` is deliberately left without a
  config file in this submission so the health check has something real
  to catch - it shows up as `[!] failed_login config missing`, matching
  what a half-finished playbook in a real registry would look like.
- Notifications (failure alerts, daily summary) are written to
  `notifications_outbox.json` instead of actually hitting email/Slack,
  since that would need real webhook credentials to demo. The message
  content follows the templates in `notification_templates/`.

## Bonus features not implemented

The manual lists a Flask dashboard, a REST API, and Splunk SOAR API
integration as optional bonus items. None of those are included here -
focused the time on getting the required registry/scheduling/monitoring/
health-check/notification features solid instead of spreading thin across
extras.
