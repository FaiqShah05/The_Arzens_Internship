#!/usr/bin/env python3
"""
phishing_playbook.py

A small SOAR-style playbook for triaging reported phishing emails.
Pulls in an email report (CLI args or a JSON file), pulls out indicators,
checks them against local + VirusTotal reputation sources, scores the risk
and decides what to do about it. Everything gets written to an audit log
so the run can be reconstructed later.

Usage:
    python phishing_playbook.py --input-file sample_email.json
    python phishing_playbook.py --sender a@b.com --subject "..." --body "..." --dry-run
    python phishing_playbook.py --input-file sample_email.json --rollback
"""

import argparse
import csv
import json
import logging
import os
import re
import sys
import uuid
from datetime import datetime

try:
    import yaml
except ImportError:
    yaml = None

try:
    import requests
except ImportError:
    requests = None


RUN_ID = datetime.now().strftime("%Y%m%d_%H%M%S")
LOG_FILE = f"playbook_run_{RUN_ID}.log"
QUARANTINE_STATE_FILE = "quarantine_state.json"

logger = logging.getLogger("phishing_playbook")


def setup_logging():
    logger.setLevel(logging.DEBUG)
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    file_handler = logging.FileHandler(LOG_FILE)
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(logging.Formatter("%(message)s"))
    console_handler.setLevel(logging.INFO)
    logger.addHandler(console_handler)


def load_config(path="config.yaml"):
    default_cfg = {
        "virustotal_api_key": "",
        "risk_thresholds": {"high": 70, "medium": 40},
        "notify_email": "security@company.com",
        "blacklist_file": "blacklist_domains.txt",
        "malware_hash_file": "malware_hashes.txt",
    }
    if yaml is None or not os.path.exists(path):
        logger.warning("config.yaml not found or pyyaml missing, using defaults")
        return default_cfg
    with open(path, "r") as f:
        loaded = yaml.safe_load(f) or {}
    default_cfg.update(loaded)
    return default_cfg


def parse_args():
    p = argparse.ArgumentParser(description="Phishing email response playbook")
    p.add_argument("--sender")
    p.add_argument("--subject")
    p.add_argument("--body")
    p.add_argument("--attachment-hash")
    p.add_argument("--input-file", help="JSON file with email report")
    p.add_argument("--dry-run", action="store_true", help="Simulate actions, don't take them")
    p.add_argument("--rollback", action="store_true", help="Undo the last quarantine action")
    p.add_argument("--config", default="config.yaml")
    return p.parse_args()


def load_email_input(args):
    """Get the raw email dict either from --input-file or CLI flags."""
    if args.input_file:
        if not os.path.exists(args.input_file):
            raise FileNotFoundError(f"Input file not found: {args.input_file}")
        with open(args.input_file, "r") as f:
            data = json.load(f)
    else:
        data = {
            "sender": args.sender,
            "subject": args.subject,
            "body": args.body,
            "attachment_hash": args.attachment_hash,
            "reported_by": "cli-user",
        }

    # basic validation - reject malformed input rather than crash halfway through
    if not data.get("sender") or "@" not in str(data.get("sender", "")):
        raise ValueError("Invalid or missing sender address")
    if not data.get("subject"):
        raise ValueError("Missing subject line")

    data.setdefault("body", "")
    data.setdefault("attachment_hash", "")
    return data


# ---------------------------------------------------------------------------
# Step 2: indicator extraction
# ---------------------------------------------------------------------------

URL_REGEX = re.compile(r"https?://[^\s\"'<>]+")
SUSPICIOUS_KEYWORDS = [
    "verify your account", "urgent", "suspended", "click here",
    "confirm your identity", "password expired", "unusual activity",
]


def extract_indicators(email):
    sender_domain = email["sender"].split("@")[-1].strip().lower()
    urls = URL_REGEX.findall(email.get("body", ""))
    keywords_found = [
        kw for kw in SUSPICIOUS_KEYWORDS
        if kw in email.get("subject", "").lower() or kw in email.get("body", "").lower()
    ]

    return {
        "sender_domain": sender_domain,
        "urls": urls,
        "attachment_hash": email.get("attachment_hash", ""),
        "keywords_found": keywords_found,
    }


# ---------------------------------------------------------------------------
# Step 3: reputation checks
# ---------------------------------------------------------------------------

def load_lines(path):
    if not os.path.exists(path):
        return set()
    with open(path) as f:
        return {line.strip().lower() for line in f if line.strip() and not line.startswith("#")}


def looks_like_typosquat(domain, legit_domains=("paypal.com", "microsoft.com", "google.com", "apple.com", "amazon.com")):
    """Very rough check - close but not exact match to a well known domain."""
    for legit in legit_domains:
        if domain == legit:
            return False
        # same length, one character different
        if len(domain) == len(legit):
            diffs = sum(1 for a, b in zip(domain, legit) if a != b)
            if diffs == 1:
                return True
        # common swap like l -> 1, o -> 0
        swapped = legit.replace("l", "1").replace("o", "0")
        if domain == swapped:
            return True
    return False


def check_domain_reputation(domain, blacklist):
    if domain in blacklist:
        return "MALICIOUS", "domain on local blacklist"
    if looks_like_typosquat(domain):
        return "SUSPICIOUS", f"{domain} looks like a typo of a known brand domain"
    return "UNKNOWN", "no local match"


def check_url_reputation(url, api_key):
    """Check a URL against VirusTotal if a key is configured, else fall back
    to a couple of obvious red flag patterns so the playbook still works offline."""
    if api_key and requests is not None:
        try:
            resp = requests.get(
                "https://www.virustotal.com/api/v3/urls",
                headers={"x-apikey": api_key},
                params={"url": url},
                timeout=5,
            )
            if resp.status_code == 200:
                stats = resp.json().get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
                malicious = stats.get("malicious", 0)
                total = sum(stats.values()) if stats else 0
                if malicious > 0:
                    return "MALICIOUS", f"VirusTotal {malicious}/{total}"
                return "CLEAN", f"VirusTotal {malicious}/{total}"
        except Exception as e:
            logger.warning(f"VirusTotal lookup failed for {url}: {e}")

    # offline heuristic fallback
    red_flags = ["evil", "phish", "login", "verify", "secure-", "-update"]
    if any(flag in url.lower() for flag in red_flags):
        return "MALICIOUS", "matched offline heuristic pattern"
    return "UNKNOWN", "no reputation data available"


def check_hash_reputation(file_hash, known_hashes):
    if not file_hash:
        return "N/A", "no attachment"
    if file_hash.lower() in known_hashes:
        return "MALICIOUS", "matches known malware hash database"
    return "UNKNOWN", "not in local malware hash list"


def run_reputation_checks(indicators, cfg):
    blacklist = load_lines(cfg["blacklist_file"])
    known_hashes = load_lines(cfg["malware_hash_file"])

    domain_status, domain_reason = check_domain_reputation(indicators["sender_domain"], blacklist)

    url_results = []
    for url in indicators["urls"]:
        status, reason = check_url_reputation(url, cfg.get("virustotal_api_key", ""))
        url_results.append({"url": url, "status": status, "reason": reason})

    hash_status, hash_reason = check_hash_reputation(indicators["attachment_hash"], known_hashes)

    return {
        "domain": {"value": indicators["sender_domain"], "status": domain_status, "reason": domain_reason},
        "urls": url_results,
        "hash": {"value": indicators["attachment_hash"], "status": hash_status, "reason": hash_reason},
    }


# ---------------------------------------------------------------------------
# Step 4: risk scoring
# ---------------------------------------------------------------------------

def calculate_risk_score(indicators, reputation):
    score = 0
    reasons = []

    if reputation["domain"]["status"] in ("MALICIOUS", "SUSPICIOUS"):
        score += 40
        reasons.append(f"Suspicious/known-bad domain (+40): {reputation['domain']['reason']}")

    if any(u["status"] == "MALICIOUS" for u in reputation["urls"]):
        score += 30
        reasons.append("Malicious URL detected (+30)")

    if reputation["hash"]["status"] == "MALICIOUS":
        score += 50
        reasons.append("Known malware hash match (+50)")

    kw_points = len(indicators["keywords_found"]) * 10
    if kw_points:
        score += kw_points
        reasons.append(f"Suspicious keywords found (+{kw_points}): {', '.join(indicators['keywords_found'])}")

    score = min(score, 100)
    return score, reasons


# ---------------------------------------------------------------------------
# Step 5: decision + action
# ---------------------------------------------------------------------------

def decide_action(score, cfg):
    thresholds = cfg["risk_thresholds"]
    if score >= thresholds["high"]:
        return "HIGH", ["quarantine_email", "block_sender", "notify_security_team"]
    if score >= thresholds["medium"]:
        return "MEDIUM", ["hold_for_review", "notify_user"]
    return "LOW", ["log_only", "deliver_with_warning"]


def execute_actions(actions, email, dry_run):
    executed = []
    for action in actions:
        if dry_run:
            logger.info(f"  [DRY-RUN] Would execute: {action}")
            executed.append({"action": action, "status": "SIMULATED"})
            continue

        # In a real environment these would call the mail server / EDR / ticketing
        # APIs. Here we just simulate the effect and record it, which is enough
        # for a training playbook and keeps the assignment self-contained.
        if action == "quarantine_email":
            save_quarantine_state(email)
        logger.info(f"  Executing: {action}")
        executed.append({"action": action, "status": "SUCCESS"})
    return executed


def save_quarantine_state(email):
    state = {"quarantined_at": datetime.now().isoformat(), "email": email, "run_id": RUN_ID}
    with open(QUARANTINE_STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def rollback_last_action():
    if not os.path.exists(QUARANTINE_STATE_FILE):
        logger.info("Nothing to roll back - no quarantine record found.")
        return False
    with open(QUARANTINE_STATE_FILE) as f:
        state = json.load(f)
    logger.info(f"Rolling back quarantine from {state['quarantined_at']} for {state['email'].get('sender')}")
    os.remove(QUARANTINE_STATE_FILE)
    logger.info("Email restored to inbox. Sender unblocked.")
    return True


# ---------------------------------------------------------------------------
# Step 6: notification
# ---------------------------------------------------------------------------

def generate_report(email, score, reasons, decision, actions, cfg):
    report = {
        "run_id": RUN_ID,
        "timestamp": datetime.now().isoformat(),
        "original_email": {"sender": email["sender"], "subject": email["subject"]},
        "risk_score": score,
        "reasoning": reasons,
        "decision": decision,
        "actions_taken": [a["action"] for a in actions],
        "notified": cfg["notify_email"],
    }
    report_file = f"report_{RUN_ID}.json"
    with open(report_file, "w") as f:
        json.dump(report, f, indent=2)
    logger.info(f"  Report sent to: {cfg['notify_email']} (saved as {report_file})")
    return report_file


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main():
    args = parse_args()
    setup_logging()
    cfg = load_config(args.config)

    print("+" + "=" * 58 + "+")
    print("|          PHISHING RESPONSE PLAYBOOK v1.0                |")
    print("+" + "=" * 58 + "+")

    if args.rollback:
        rollback_last_action()
        return

    try:
        email = load_email_input(args)
    except (ValueError, FileNotFoundError) as e:
        logger.error(f"Input validation failed: {e}")
        sys.exit(1)

    logger.info(f"\nInput: {email['sender']} - \"{email['subject']}\"")

    logger.info("\nSTEP 1: Extracting indicators...")
    indicators = extract_indicators(email)
    logger.info(f"  Domain: {indicators['sender_domain']}")
    logger.info(f"  URLs: {indicators['urls']}")
    logger.info(f"  Hash: {indicators['attachment_hash']}")

    logger.info("\nSTEP 2: Checking reputation...")
    try:
        reputation = run_reputation_checks(indicators, cfg)
    except Exception as e:
        # one failed check shouldn't kill the whole run
        logger.error(f"Reputation check failed, continuing with partial data: {e}")
        reputation = {"domain": {"status": "UNKNOWN", "reason": "check failed"}, "urls": [], "hash": {"status": "UNKNOWN", "reason": "check failed"}}

    logger.info(f"  Domain: {reputation['domain']['value']} - {reputation['domain']['status']} ({reputation['domain']['reason']})")
    for u in reputation["urls"]:
        logger.info(f"  URL: {u['url']} - {u['status']} ({u['reason']})")
    logger.info(f"  Hash: {reputation['hash']['value']} - {reputation['hash']['status']}")

    logger.info("\nSTEP 3: Calculating risk score...")
    score, reasons = calculate_risk_score(indicators, reputation)
    for r in reasons:
        logger.info(f"  {r}")
    logger.info(f"  Total Risk Score: {score}/100")

    decision, actions_to_run = decide_action(score, cfg)
    logger.info(f"  Classification: {decision}")

    logger.info("\nSTEP 4: Taking action...")
    if args.dry_run:
        logger.info("  [DRY-RUN MODE - No real actions taken]")
    executed = execute_actions(actions_to_run, email, args.dry_run)

    logger.info("\nSTEP 5: Generating report...")
    generate_report(email, score, reasons, decision, executed, cfg)

    logger.info(f"\nAUDIT LOG: {LOG_FILE}")


if __name__ == "__main__":
    main()
