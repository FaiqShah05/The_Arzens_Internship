#!/usr/bin/env python3
"""
Checksum verification for the normalizer's inputs and outputs.
Records MD5/SHA-256 hashes so anyone can confirm they got byte-identical
results from the same input file.

Author: Faiq Shah
"""

import argparse
import hashlib
from datetime import datetime, timezone
from pathlib import Path

CHECKSUM_FILE = "checksums.txt"


def hash_file(path):
    data = Path(path).read_bytes()
    return {
        "md5": hashlib.md5(data).hexdigest(),
        "sha256": hashlib.sha256(data).hexdigest(),
    }


def record_checksums(files, out_path=CHECKSUM_FILE):
    lines = []
    for label, path in files:
        if not Path(path).exists():
            lines.append(f"{label}: {path}\n  MISSING\n")
            continue
        hashes = hash_file(path)
        lines.append(
            f"{label}: {path}\n"
            f"  MD5: {hashes['md5']}\n"
            f"  SHA256: {hashes['sha256']}\n"
            f"  Generated: {datetime.now(timezone.utc).isoformat()}\n"
        )

    with open(out_path, "w") as f:
        f.write("\n".join(lines))
    return lines


def verify_checksums(files, checksum_path=CHECKSUM_FILE):
    if not Path(checksum_path).exists():
        print(f"No {checksum_path} found - nothing to verify against. Run without --verify first.")
        return False

    saved = Path(checksum_path).read_text()
    ok = True
    for label, path in files:
        if not Path(path).exists():
            print(f"[FAIL] {label}: {path} does not exist")
            ok = False
            continue
        current = hash_file(path)
        if current["sha256"] not in saved:
            print(f"[FAIL] {label}: {path} - SHA256 does not match recorded checksum")
            ok = False
        else:
            print(f"[PASS] {label}: {path} - checksum matches")
    return ok


def main():
    parser = argparse.ArgumentParser(description="Hash and verify normalizer input/output files")
    parser.add_argument("--input", default="sample_mixed_logs.txt")
    parser.add_argument("--output-csv", default="sample_clean.csv")
    parser.add_argument("--output-json", default="sample_clean.json")
    parser.add_argument("--verify", action="store_true", help="Verify against previously recorded checksums")
    args = parser.parse_args()

    files = [
        ("Input", args.input),
        ("Output CSV", args.output_csv),
        ("Output JSON", args.output_json),
    ]

    if args.verify:
        passed = verify_checksums(files)
        print("\nReproducibility: VERIFIED" if passed else "\nReproducibility: FAILED")
    else:
        lines = record_checksums(files)
        print("\n".join(lines))
        print(f"Checksums written to {CHECKSUM_FILE}")


if __name__ == "__main__":
    main()
