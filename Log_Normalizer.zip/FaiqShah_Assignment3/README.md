# THE ARZENS Security Log Normalizer

Takes messy, mixed-format security logs (firewall, auth, DNS, JSON file
access) and turns them into a consistent CSV/JSON schema — timestamps
normalized to ISO 8601 UTC, fields validated, duplicates removed. Built for
Assignment 3 of the Beginner Track (AI, Automation & Security Engineering)
at The Arzens.

## What's in here

| File | Purpose |
|---|---|
| `normalizer.py` | Core normalizer (Task 2) |
| `sample_mixed_logs.txt` | 25 lines mixing all 4 formats + intentional messiness |
| `sample_clean.csv` / `sample_clean.json` | Expected output from the sample input |
| `data_dictionary.txt` | What every output field means |
| `requirements.txt` | Pinned dependencies (standard library only) |
| `checksum.py` | Hashes input/output for integrity verification (Task 3) |
| `test_reproducibility.py` | Confirms two runs produce identical output (Task 3) |
| `ENVIRONMENT.md` | Python version, OS, venv setup |
| `checksums.txt` | Sample checksum output from a real run |
| `research/` | Task 1 comparison note (docx + pdf) |

## Installation

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Nothing external actually needs installing — the normalizer only uses the
standard library — but this gets you a clean, known environment.

## Usage

Basic run:
```bash
python normalizer.py --input sample_mixed_logs.txt --output-csv clean.csv --output-json clean.json
```

With deduplication:
```bash
python normalizer.py --input sample_mixed_logs.txt --output-csv clean.csv --output-json clean.json --deduplicate
```

Force a specific parser instead of auto-detecting format:
```bash
python normalizer.py --input firewall_only.txt --format firewall --output-csv clean.csv --output-json clean.json
```

## Expected output

- `clean.csv` — one row per event, columns: `timestamp, source_ip,
  event_type, user, action, target, bytes, status`
- `clean.json` — same records as a JSON array, with an extra `original_log`
  field per record for traceability
- `errors.log` — one line per skipped/malformed input line, with the line
  number and reason
- A console summary: total lines read, successfully parsed, skipped, and
  duplicates removed

## Verifying reproducibility

```bash
python checksum.py                 # hashes input + output, writes checksums.txt
python checksum.py --verify        # re-hashes and compares against checksums.txt
python test_reproducibility.py     # runs the normalizer twice and diffs the output
```

## Troubleshooting

- **"unrecognized format" for every line in errors.log** — the input file
  probably uses a log format the normalizer doesn't know about, or
  `--format` was set to something that doesn't match your actual logs. Try
  `--format auto` (the default).
- **Timestamps look off by a few hours** — the normalizer assumes all
  input timestamps are already in UTC (or explicitly marked as such, like
  `...Z`). It doesn't do timezone conversion from local time.
- **Syslog lines (`Jul 20 14:23:45 ...`) get the wrong year** — syslog
  format has no year field, so the normalizer assumes the current year at
  runtime. If you're normalizing old logs, this will be wrong — patch
  `parse_ts_syslog()`'s `year` argument if you need a fixed year.
- **`checksum.py --verify` fails right after generating a fresh
  `checksums.txt`** — make sure you're pointing it at the same
  `--input/--output-csv/--output-json` paths you used when you generated
  the checksums; it compares by filename.

## AI Assistance Note

I used Claude (Anthropic) to help scaffold this project — structuring the
per-format parsers, the timestamp normalization logic, and the
reproducibility/checksum scripts. I reviewed the generated code, adjusted
the parsing logic and test data myself, and verified everything against
the sample data included here.
