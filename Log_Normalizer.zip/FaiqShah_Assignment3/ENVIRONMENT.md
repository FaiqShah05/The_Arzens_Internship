# Environment Documentation

## Python version
- Developed and tested on Python 3.12.3
- Minimum required: Python >= 3.9 (uses `datetime.fromisoformat`, `ipaddress`,
  f-strings, and standard `argparse` — nothing newer than 3.9 needs)

## Operating system
- Developed and tested on Linux (Ubuntu-based container, kernel 6.18)
- No OS-specific code is used (no hardcoded path separators, no shell-only
  calls) so it should run unchanged on Windows and macOS as well

## Virtual environment setup

Using `venv` (recommended):
```bash
python3 -m venv venv
source venv/bin/activate       # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

Using `conda`:
```bash
conda create -n arzens-normalizer python=3.12
conda activate arzens-normalizer
pip install -r requirements.txt
```

There's nothing to actually install from `requirements.txt` for this
submission — everything is standard library — but the venv step still
matters so you're running a known Python version rather than whatever
happens to be on PATH.

## Date created and last tested
- Created: 2026-08-02
- Last tested: 2026-08-02 (all three scripts run clean; reproducibility
  test passes; checksum verification passes)
