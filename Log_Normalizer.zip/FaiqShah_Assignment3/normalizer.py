#!/usr/bin/env python3
"""
THE ARZENS Security Log Normalizer
Reads mixed-format security logs (firewall, auth, DNS, JSON), cleans and
validates them, and exports a consistent CSV/JSON schema.

Author: Faiq Shah
"""

import argparse
import csv
import ipaddress
import json
import re
from datetime import datetime, timezone

FIELDNAMES = ["timestamp", "source_ip", "event_type", "user", "action", "target", "bytes", "status"]

FIREWALL_RE = re.compile(
    r"^\[(?P<ts>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]\s+FIREWALL\s+"
    r"src=(?P<src>\S+)\s+dst=(?P<dst>\S+)\s+action=(?P<action>\S+)\s+"
    r"port=(?P<port>\d+)\s+bytes=(?P<bytes>\d+)"
)

DNS_RE = re.compile(
    r"^(?P<ts>[A-Za-z]{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+dns-server\s+named\[\d+\]:\s+"
    r"query:\s+(?P<domain>\S+)\s+IN\s+A\s+from\s+(?P<src>\S+)"
)

MALICIOUS_HINTS = ("malicious", "malware", "phish", "c2-")


def parse_ts_bracket(ts_str):
    dt = datetime.strptime(ts_str, "%Y-%m-%d %H:%M:%S")
    return dt.replace(tzinfo=timezone.utc)


def parse_ts_iso(ts_str):
    dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
    return dt.astimezone(timezone.utc)


def parse_ts_syslog(ts_str, year):
    dt = datetime.strptime(f"{year} {ts_str}", "%Y %b %d %H:%M:%S")
    return dt.replace(tzinfo=timezone.utc)


def to_iso(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def is_valid_ip(value):
    try:
        ipaddress.IPv4Address(value)
        return True
    except (ipaddress.AddressValueError, ValueError):
        return False


def is_private_ip(value):
    try:
        return ipaddress.IPv4Address(value).is_private
    except (ipaddress.AddressValueError, ValueError):
        return False


def looks_malicious(target):
    target = (target or "").lower()
    return any(hint in target for hint in MALICIOUS_HINTS)


# ---------- individual parsers ----------

def parse_firewall(line):
    m = FIREWALL_RE.match(line.strip())
    if not m:
        return None
    ts = parse_ts_bracket(m.group("ts"))
    bytes_val = int(m.group("bytes"))
    if bytes_val <= 0:
        raise ValueError("bytes must be > 0")
    port = int(m.group("port"))
    if not (1 <= port <= 65535):
        raise ValueError("port out of range")

    src = m.group("src")
    status = "VALID" if is_valid_ip(src) else "FLAGGED"

    return {
        "timestamp": to_iso(ts),
        "source_ip": src,
        "event_type": "FIREWALL",
        "user": "SYSTEM",
        "action": m.group("action").upper(),
        "target": m.group("dst"),
        "bytes": bytes_val,
        "status": status,
    }


def parse_auth(line):
    parts = [p.strip() for p in line.strip().split(",")]
    if len(parts) != 6:
        return None
    ts_str, server, event, user, src, result = parts
    if event.upper() != "LOGIN":
        return None

    ts = parse_ts_iso(ts_str)
    action_map = {"SUCCESS": "SUCCESS", "FAILURE": "FAILURE", "FAIL": "FAILURE"}
    action = action_map.get(result.upper(), result.upper())
    status = "VALID" if is_valid_ip(src) else "FLAGGED"

    return {
        "timestamp": to_iso(ts),
        "source_ip": src,
        "event_type": "AUTH",
        "user": user if user else "UNKNOWN",
        "action": action,
        "target": server,
        "bytes": 0,
        "status": status,
    }


def parse_dns(line):
    m = DNS_RE.match(line.strip())
    if not m:
        return None
    ts = parse_ts_syslog(m.group("ts"), year=datetime.now().year)
    src = m.group("src")
    domain = m.group("domain")
    status = "FLAGGED" if looks_malicious(domain) else ("VALID" if is_valid_ip(src) else "FLAGGED")

    return {
        "timestamp": to_iso(ts),
        "source_ip": src,
        "event_type": "DNS",
        "user": "SYSTEM",
        "action": "QUERY",
        "target": domain,
        "bytes": 0,
        "status": status,
    }


def parse_json_line(line):
    try:
        data = json.loads(line.strip())
    except json.JSONDecodeError:
        return None
    if "event" not in data or "timestamp" not in data:
        return None

    ts = parse_ts_bracket(data["timestamp"])
    action = str(data.get("action", "UNKNOWN")).upper()

    return {
        "timestamp": to_iso(ts),
        "source_ip": data.get("source_ip", None),
        "event_type": "FILE",
        "user": data.get("user") or "UNKNOWN",
        "action": action,
        "target": data.get("file", "UNKNOWN"),
        "bytes": int(data.get("bytes", 0)),
        "status": "VALID",
    }


PARSERS = {
    "firewall": parse_firewall,
    "auth": parse_auth,
    "dns": parse_dns,
    "json": parse_json_line,
}


def parse_line(line, forced_format=None):
    if forced_format and forced_format != "auto":
        parser = PARSERS[forced_format]
        return parser(line)

    for parser in PARSERS.values():
        try:
            result = parser(line)
        except ValueError:
            raise
        if result:
            return result
    return None


# ---------- cleaning ----------

def clean_record(record, raw_line):
    for key in FIELDNAMES:
        if key not in record or record[key] in ("", None):
            if key == "source_ip":
                record[key] = None
            elif key not in ("bytes",):
                record[key] = "UNKNOWN"

    record["original_log"] = raw_line.strip()
    return record


def dedupe_key(record):
    try:
        ts = datetime.strptime(record["timestamp"], "%Y-%m-%dT%H:%M:%SZ")
        ts_bucket = ts.replace(microsecond=0)
    except ValueError:
        ts_bucket = record["timestamp"]
    return (ts_bucket, record.get("source_ip"), record.get("action"))


# ---------- main pipeline ----------

def normalize_file(input_path, forced_format="auto", deduplicate=False):
    records = []
    errors = []
    seen = set()
    duplicates_removed = 0
    skipped = 0

    with open(input_path, "r", encoding="utf-8", errors="replace") as f:
        lines = f.readlines()

    for i, raw_line in enumerate(lines, start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            parsed = parse_line(line, forced_format)
        except ValueError as e:
            errors.append(f"Line {i}: validation error - {e}")
            skipped += 1
            continue

        if parsed is None:
            errors.append(f"Line {i}: unrecognized format")
            skipped += 1
            continue

        record = clean_record(parsed, raw_line)

        if deduplicate:
            key = dedupe_key(record)
            if key in seen:
                duplicates_removed += 1
                continue
            seen.add(key)

        records.append(record)

    records.sort(key=lambda r: (r["timestamp"], r.get("source_ip") or ""))

    stats = {
        "total_lines": len(lines),
        "parsed": len(records),
        "skipped": skipped,
        "duplicates_removed": duplicates_removed,
    }
    return records, errors, stats


def write_csv(records, path):
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        for r in records:
            writer.writerow({k: r.get(k) for k in FIELDNAMES})


def write_json(records, path):
    with open(path, "w") as f:
        json.dump(records, f, indent=2)


def write_errors(errors, path):
    with open(path, "w") as f:
        for e in errors:
            f.write(e + "\n")


def main():
    parser = argparse.ArgumentParser(description="Normalize mixed-format security logs")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--format", choices=["auto", "firewall", "auth", "dns", "json"], default="auto")
    parser.add_argument("--deduplicate", action="store_true")
    parser.add_argument("--error-log", default="errors.log")
    args = parser.parse_args()

    records, errors, stats = normalize_file(args.input, args.format, args.deduplicate)

    write_csv(records, args.output_csv)
    write_json(records, args.output_json)
    write_errors(errors, args.error_log)

    print("Normalization complete.")
    print(f"  Total lines read:   {stats['total_lines']}")
    print(f"  Successfully parsed:{stats['parsed']}")
    print(f"  Skipped (malformed):{stats['skipped']}")
    print(f"  Duplicates removed: {stats['duplicates_removed']}")
    print(f"  CSV written to:     {args.output_csv}")
    print(f"  JSON written to:    {args.output_json}")
    if errors:
        print(f"  Errors logged to:   {args.error_log}")


if __name__ == "__main__":
    main()
