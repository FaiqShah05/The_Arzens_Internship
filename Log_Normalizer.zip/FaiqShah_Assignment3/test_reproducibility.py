#!/usr/bin/env python3
"""
Runs normalizer.py twice on the same input and confirms the outputs are
byte-identical. This is what "reproducible" actually means here - not
"looks about right", but "produces the exact same file every time".

Author: Faiq Shah
"""

import subprocess
import sys
import tempfile
from pathlib import Path

INPUT_FILE = "sample_mixed_logs.txt"


def run_normalizer(csv_out, json_out):
    result = subprocess.run(
        [
            sys.executable, "normalizer.py",
            "--input", INPUT_FILE,
            "--output-csv", csv_out,
            "--output-json", json_out,
            "--deduplicate",
        ],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        print(result.stderr)
        raise RuntimeError("normalizer.py failed to run")


def main():
    if not Path(INPUT_FILE).exists():
        print(f"FAIL: {INPUT_FILE} not found")
        sys.exit(1)

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        csv_a, json_a = tmp / "run1.csv", tmp / "run1.json"
        csv_b, json_b = tmp / "run2.csv", tmp / "run2.json"

        run_normalizer(str(csv_a), str(json_a))
        run_normalizer(str(csv_b), str(json_b))

        csv_match = csv_a.read_bytes() == csv_b.read_bytes()
        json_match = json_a.read_bytes() == json_b.read_bytes()

        print(f"CSV outputs identical:  {csv_match}")
        print(f"JSON outputs identical: {json_match}")

        if csv_match and json_match:
            print("\nPASS: normalizer.py is reproducible on this input.")
            sys.exit(0)
        else:
            print("\nFAIL: outputs differed between runs.")
            sys.exit(1)


if __name__ == "__main__":
    main()
