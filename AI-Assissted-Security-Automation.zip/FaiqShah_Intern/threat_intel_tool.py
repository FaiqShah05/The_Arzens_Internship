#!/usr/bin/env python3
"""
THE ARZENS Threat Intelligence Enricher
Queries VirusTotal, AbuseIPDB, and AlienVault OTX to check the reputation
of IPs, domains, hashes and URLs, and prints a combined verdict.

Author: Faiq Shah
"""

import argparse
import csv
import json
import os
import re
import sys
import time
from datetime import datetime, timezone

import requests
import yaml
from dotenv import load_dotenv

try:
    from colorama import Fore, Style, init as colorama_init
    colorama_init(autoreset=True)
except ImportError:
    class _Dummy:
        def __getattr__(self, name):
            return ""
    Fore = Style = _Dummy()

CACHE_FILE = "cache.json"
MAX_RETRIES = 3


# ---------- config ----------

def load_config(path="config.yaml"):
    load_dotenv()
    config = {}
    if os.path.exists(path):
        with open(path, "r") as f:
            config = yaml.safe_load(f) or {}

    # env vars override / fill in whatever's missing from the yaml
    config.setdefault("virustotal", {}).setdefault(
        "api_keys", [k for k in [os.getenv("VT_API_KEY")] if k]
    )
    config.setdefault("abuseipdb", {}).setdefault(
        "api_keys", [k for k in [os.getenv("ABUSEIPDB_API_KEY")] if k]
    )
    config.setdefault("otx", {}).setdefault(
        "api_keys", [k for k in [os.getenv("OTX_API_KEY")] if k]
    )
    return config


# ---------- caching ----------

def load_cache():
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_cache(cache):
    with open(CACHE_FILE, "w") as f:
        json.dump(cache, f, indent=2)


# ---------- input validation ----------

IP_RE = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")
DOMAIN_RE = re.compile(r"^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9-]+)+$")
HASH_RE = re.compile(r"^[a-fA-F0-9]{32}$|^[a-fA-F0-9]{40}$|^[a-fA-F0-9]{64}$")
URL_RE = re.compile(r"^https?://", re.IGNORECASE)


def detect_type(indicator):
    if IP_RE.match(indicator):
        return "ip"
    if HASH_RE.match(indicator):
        return "hash"
    if URL_RE.match(indicator):
        return "url"
    if DOMAIN_RE.match(indicator):
        return "domain"
    return None


def is_safe_indicator(indicator, indicator_type):
    """Basic sanity check so we never hand raw user input straight to a URL."""
    if not indicator or len(indicator) > 253:
        return False
    if any(c in indicator for c in [" ", "\t", "\n", ";", "|", "&", "`"]):
        return False
    if indicator_type == "ip":
        return bool(IP_RE.match(indicator))
    if indicator_type == "domain":
        return bool(DOMAIN_RE.match(indicator))
    if indicator_type == "hash":
        return bool(HASH_RE.match(indicator))
    if indicator_type == "url":
        return bool(URL_RE.match(indicator))
    return False


# ---------- HTTP helper with retries ----------

def request_with_retry(method, url, **kwargs):
    delay = 1
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            resp = requests.request(method, url, timeout=15, **kwargs)
        except requests.RequestException as e:
            if attempt == MAX_RETRIES:
                return None, str(e)
            time.sleep(delay)
            delay *= 2
            continue

        if resp.status_code == 200:
            return resp, None
        if resp.status_code == 401:
            return None, "401 Unauthorized - check your API key"
        if resp.status_code == 429:
            if attempt == MAX_RETRIES:
                return None, "429 Rate limited - out of retries"
            time.sleep(delay)
            delay *= 2
            continue
        if resp.status_code >= 500:
            if attempt == MAX_RETRIES:
                return None, f"{resp.status_code} server error"
            time.sleep(delay)
            delay *= 2
            continue
        return None, f"Unexpected status {resp.status_code}"
    return None, "Retries exhausted"


# ---------- VirusTotal ----------

def query_virustotal(indicator, indicator_type, config):
    keys = config.get("virustotal", {}).get("api_keys", [])
    if not keys:
        return {"error": "No VirusTotal API key configured"}

    base = "https://www.virustotal.com/vtapi/v2"
    params = {"apikey": keys[0]}

    if indicator_type == "ip":
        url, params["ip"] = f"{base}/ip-address/report", indicator
    elif indicator_type == "domain":
        url, params["domain"] = f"{base}/domain/report", indicator
    elif indicator_type == "hash":
        url, params["resource"] = f"{base}/file/report", indicator
    elif indicator_type == "url":
        url, params["resource"] = f"{base}/url/report", indicator
    else:
        return {"error": "Unsupported indicator type for VirusTotal"}

    resp, err = request_with_retry("GET", url, params=params)
    time.sleep(15)  # stay under 4 req/min on the free tier
    if err:
        return {"error": err}

    data = resp.json()
    positives = data.get("positives", 0)
    total = data.get("total", 0)
    ratio = f"{positives}/{total} ({(positives / total * 100) if total else 0:.1f}%)"

    if positives == 0:
        verdict = "CLEAN"
    elif positives / total < 0.1 if total else False:
        verdict = "SUSPICIOUS"
    else:
        verdict = "MALICIOUS"

    return {
        "detection_ratio": ratio,
        "positives": positives,
        "total": total,
        "categories": data.get("categories", []) or data.get("Webutation domain verdict", []),
        "first_seen": data.get("scan_date", "unknown"),
        "verdict": verdict,
    }


# ---------- AbuseIPDB ----------

def query_abuseipdb(indicator, indicator_type, config):
    if indicator_type != "ip":
        return {"error": "AbuseIPDB only supports IP addresses"}

    keys = config.get("abuseipdb", {}).get("api_keys", [])
    if not keys:
        return {"error": "No AbuseIPDB API key configured"}

    url = "https://api.abuseipdb.com/api/v2/check"
    headers = {"Key": keys[0], "Accept": "application/json"}
    params = {"ipAddress": indicator, "maxAgeInDays": 90}

    resp, err = request_with_retry("GET", url, headers=headers, params=params)
    if err:
        return {"error": err}

    data = resp.json().get("data", {})
    score = data.get("abuseConfidenceScore", 0)
    verdict = "CLEAN" if score < 25 else "SUSPICIOUS" if score < 75 else "MALICIOUS"

    return {
        "confidence_score": score,
        "total_reports": data.get("totalReports", 0),
        "last_reported": data.get("lastReportedAt", "never"),
        "categories": data.get("reports", [])[:1] and "see reports" or "n/a",
        "verdict": verdict,
    }


# ---------- AlienVault OTX ----------

def query_otx(indicator, indicator_type, config):
    if indicator_type not in ("ip", "domain"):
        return {"error": "OTX lookup here only supports IP and domain"}

    keys = config.get("otx", {}).get("api_keys", [])
    if not keys:
        return {"error": "No OTX API key configured"}

    section = "IPv4" if indicator_type == "ip" else "domain"
    url = f"https://otx.alienvault.com/api/v1/indicators/{section}/{indicator}/general"
    headers = {"X-OTX-API-KEY": keys[0]}

    resp, err = request_with_retry("GET", url, headers=headers)
    if err:
        return {"error": err}

    data = resp.json()
    pulse_info = data.get("pulse_info", {})
    pulse_count = pulse_info.get("count", 0)
    tags = []
    for pulse in pulse_info.get("pulses", [])[:5]:
        tags.extend(pulse.get("tags", []))
    tags = list(dict.fromkeys(tags))[:10]

    verdict = "CLEAN" if pulse_count == 0 else "SUSPICIOUS" if pulse_count < 5 else "MALICIOUS"

    return {
        "pulse_count": pulse_count,
        "tags": tags,
        "verdict": verdict,
    }


# ---------- orchestration ----------

def overall_verdict(results):
    verdicts = [r.get("verdict") for r in results.values() if isinstance(r, dict) and "verdict" in r]
    if not verdicts:
        return "UNKNOWN"
    if "MALICIOUS" in verdicts:
        return "MALICIOUS"
    if "SUSPICIOUS" in verdicts:
        return "SUSPICIOUS"
    return "CLEAN"


def enrich_indicator(indicator, config, cache, use_cache=True):
    indicator_type = detect_type(indicator)
    if indicator_type is None or not is_safe_indicator(indicator, indicator_type):
        return {"indicator": indicator, "type": "unknown", "error": "Could not validate indicator"}

    cache_key = f"{indicator_type}:{indicator}"
    if use_cache and cache_key in cache:
        return cache[cache_key]

    results = {}
    if indicator_type in ("ip", "domain", "hash", "url"):
        vt = query_virustotal(indicator, indicator_type, config)
        if "error" not in vt:
            results["virustotal"] = vt
    if indicator_type == "ip":
        abuse = query_abuseipdb(indicator, indicator_type, config)
        if "error" not in abuse:
            results["abuseipdb"] = abuse
    if indicator_type in ("ip", "domain"):
        otx = query_otx(indicator, indicator_type, config)
        if "error" not in otx:
            results["otx"] = otx

    record = {
        "indicator": indicator,
        "type": indicator_type,
        "query_time": datetime.now(timezone.utc).isoformat(),
        "results": results,
        "overall_verdict": overall_verdict(results),
    }

    cache[cache_key] = record
    return record


# ---------- output formatting ----------

VERDICT_COLORS = {
    "CLEAN": Fore.GREEN,
    "SUSPICIOUS": Fore.YELLOW,
    "MALICIOUS": Fore.RED,
    "UNKNOWN": Fore.WHITE,
}


def print_console(record):
    print("+" + "=" * 58 + "+")
    print("|      THE ARZENS THREAT INTELLIGENCE ENRICHER v1.0      |")
    print("+" + "=" * 58 + "+\n")
    print(f"Indicator: {record['indicator']} ({record['type']})")
    print(f"Query Time: {record['query_time']}\n")

    for source, data in record["results"].items():
        color = VERDICT_COLORS.get(data.get("verdict", "UNKNOWN"), "")
        print(f"{source.upper()}:")
        for key, val in data.items():
            if key == "verdict":
                continue
            print(f"  {key.replace('_', ' ').title()}: {val}")
        print(f"  Verdict: {color}{data.get('verdict', 'UNKNOWN')}{Style.RESET_ALL}\n")

    overall = record["overall_verdict"]
    color = VERDICT_COLORS.get(overall, "")
    print("+" + "=" * 58 + "+")
    print(f"| OVERALL VERDICT: {color}{overall}{Style.RESET_ALL}")
    print(f"| Recommendation: {recommend_action(overall)}")
    print("+" + "=" * 58 + "+")


def recommend_action(verdict):
    return {
        "MALICIOUS": "Block immediately, investigate logs",
        "SUSPICIOUS": "Monitor closely, consider blocking",
        "CLEAN": "No action needed",
        "UNKNOWN": "Insufficient data - manual review",
    }.get(verdict, "Manual review")


def write_json(records, path):
    with open(path, "w") as f:
        json.dump(records, f, indent=2)


def write_csv(records, path):
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["indicator", "type", "overall_verdict", "vt_detection", "abuseipdb_score", "otx_pulses"])
        for r in records:
            res = r.get("results", {})
            writer.writerow([
                r["indicator"],
                r["type"],
                r["overall_verdict"],
                res.get("virustotal", {}).get("detection_ratio", "n/a"),
                res.get("abuseipdb", {}).get("confidence_score", "n/a"),
                res.get("otx", {}).get("pulse_count", "n/a"),
            ])


def write_report(records, path):
    with open(path, "w") as f:
        f.write("THE ARZENS - Threat Intelligence Report\n")
        f.write(f"Generated: {datetime.now(timezone.utc).isoformat()}\n")
        f.write(f"Indicators analyzed: {len(records)}\n\n")
        counts = {"CLEAN": 0, "SUSPICIOUS": 0, "MALICIOUS": 0, "UNKNOWN": 0}
        for r in records:
            counts[r["overall_verdict"]] = counts.get(r["overall_verdict"], 0) + 1
            f.write(f"- {r['indicator']} ({r['type']}): {r['overall_verdict']}\n")
        f.write("\nSummary:\n")
        for verdict, count in counts.items():
            f.write(f"  {verdict}: {count}\n")


# ---------- CLI ----------

def gather_indicators(args):
    indicators = []
    if args.ip:
        indicators.append(args.ip)
    if args.domain:
        indicators.append(args.domain)
    if args.hash:
        indicators.append(args.hash)
    if args.url:
        indicators.append(args.url)

    if args.input_file:
        with open(args.input_file) as f:
            indicators.extend([line.strip() for line in f if line.strip()])

    if args.interactive:
        print("Interactive mode - enter indicators one per line, blank line to finish.")
        while True:
            line = input("> ").strip()
            if not line:
                break
            indicators.append(line)

    return indicators


def main():
    parser = argparse.ArgumentParser(description="THE ARZENS Threat Intelligence Enricher")
    parser.add_argument("--ip", help="Single IP address to check")
    parser.add_argument("--domain", help="Single domain to check")
    parser.add_argument("--hash", help="Single file hash to check")
    parser.add_argument("--url", help="Single URL to check")
    parser.add_argument("--input-file", help="Text file with one indicator per line")
    parser.add_argument("--interactive", action="store_true", help="Prompt for indicators interactively")
    parser.add_argument("--config", default="config.yaml", help="Path to config.yaml")
    parser.add_argument("--no-cache", action="store_true", help="Skip the cache and re-query everything")
    parser.add_argument("--json-out", help="Write JSON results to this path")
    parser.add_argument("--csv-out", help="Write CSV results to this path")
    parser.add_argument("--report-out", help="Write a text summary report to this path")
    args = parser.parse_args()

    indicators = gather_indicators(args)
    if not indicators:
        parser.error("No indicators provided. Use --ip/--domain/--hash/--url, --input-file, or --interactive.")

    config = load_config(args.config)
    cache = load_cache()

    records = []
    for indicator in indicators:
        record = enrich_indicator(indicator, config, cache, use_cache=not args.no_cache)
        records.append(record)
        if "error" in record:
            print(f"[!] {indicator}: {record['error']}")
            continue
        print_console(record)

    save_cache(cache)

    if args.json_out:
        write_json(records, args.json_out)
    if args.csv_out:
        write_csv(records, args.csv_out)
    if args.report_out:
        write_report(records, args.report_out)


if __name__ == "__main__":
    main()
