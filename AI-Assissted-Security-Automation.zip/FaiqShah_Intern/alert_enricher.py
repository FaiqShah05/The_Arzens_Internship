#!/usr/bin/env python3
"""
Alert Enrichment Pipeline
Takes a single alert (JSON), enriches the indicator using threat_intel_tool,
scores the risk, and writes a timestamped incident report.

Author: Faiq Shah
"""

import argparse
import json
import logging
import os
from datetime import datetime, timezone

from threat_intel_tool import load_config, load_cache, save_cache, enrich_indicator

logging.basicConfig(
    filename="workflow.log",
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)


SEVERITY_WEIGHTS = {"low": 10, "medium": 30, "high": 50, "critical": 70}


def calculate_risk_score(record, alert_severity):
    """Simple weighted score: base severity + how bad the enrichment looks."""
    score = SEVERITY_WEIGHTS.get(alert_severity.lower(), 20)
    results = record.get("results", {})

    vt = results.get("virustotal", {})
    if vt.get("total"):
        score += min(20, (vt.get("positives", 0) / vt["total"]) * 20)

    abuse = results.get("abuseipdb", {})
    score += abuse.get("confidence_score", 0) * 0.2

    otx = results.get("otx", {})
    score += min(10, otx.get("pulse_count", 0))

    return min(100, round(score))


def recommend_actions(risk_score):
    actions = []
    if risk_score >= 80:
        actions.append("IMMEDIATE: Block IP/domain at firewall")
        actions.append("INVESTIGATE: Check internal hosts that contacted this indicator")
        actions.append("HUNT: Search logs for similar indicators")
        actions.append("ESCALATE: Notify Tier 2 analyst")
    elif risk_score >= 50:
        actions.append("MONITOR: Add to watchlist")
        actions.append("INVESTIGATE: Review related traffic logs")
    elif risk_score >= 20:
        actions.append("MONITOR: Low priority, revisit if repeated")
    else:
        actions.append("IGNORE: No action required")
    return actions


def build_incident_id():
    return f"INC-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}"


def generate_report(alert, record, risk_score, incident_id):
    lines = []
    lines.append("=" * 51)
    lines.append(f"INCIDENT REPORT: {incident_id}")
    lines.append(f"Generated: {datetime.now(timezone.utc).isoformat()}")
    lines.append("=" * 51)
    lines.append("")
    lines.append("ALERT DETAILS:")
    lines.append(f"  Type: {alert.get('alert_type')}")
    lines.append(f"  Indicator: {alert.get('indicator')}")
    lines.append(f"  Severity: {alert.get('severity')}")
    lines.append(f"  Source: {alert.get('source')}")
    lines.append("")
    lines.append("ENRICHMENT RESULTS:")
    for source, data in record.get("results", {}).items():
        summary_bits = []
        if "detection_ratio" in data:
            summary_bits.append(f"{data['detection_ratio']} detections")
        if "confidence_score" in data:
            summary_bits.append(f"Confidence: {data['confidence_score']}/100, {data.get('total_reports', 0)} reports")
        if "pulse_count" in data:
            summary_bits.append(f"{data['pulse_count']} pulses, tags: {data.get('tags', [])}")
        lines.append(f"  [{source.upper()}] {', '.join(summary_bits)} - {data.get('verdict')}")
    lines.append("")
    lines.append(f"RISK SCORE: {risk_score}/100 ({risk_bucket(risk_score)})")
    lines.append("")
    lines.append("RECOMMENDED ACTIONS:")
    for i, action in enumerate(recommend_actions(risk_score), start=1):
        lines.append(f"  {i}. {action}")
    lines.append("=" * 51)
    return "\n".join(lines)


def risk_bucket(score):
    if score >= 80:
        return "CRITICAL"
    if score >= 50:
        return "HIGH"
    if score >= 20:
        return "MEDIUM"
    return "LOW"


def main():
    parser = argparse.ArgumentParser(description="Enrich a single alert and generate an incident report")
    parser.add_argument("--alert", required=True, help="Path to alert JSON file")
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument("--out-dir", default="incidents")
    args = parser.parse_args()

    with open(args.alert) as f:
        alert = json.load(f)

    logging.info("Processing alert for indicator %s", alert.get("indicator"))

    config = load_config(args.config)
    cache = load_cache()

    try:
        record = enrich_indicator(alert["indicator"], config, cache)
    except Exception as e:
        logging.error("Enrichment failed for %s: %s", alert.get("indicator"), e)
        print(f"[!] Enrichment failed: {e}")
        return
    finally:
        save_cache(cache)

    risk_score = calculate_risk_score(record, alert.get("severity", "medium"))
    incident_id = build_incident_id()
    report = generate_report(alert, record, risk_score, incident_id)

    os.makedirs(args.out_dir, exist_ok=True)
    out_path = os.path.join(args.out_dir, f"{incident_id}.txt")
    with open(out_path, "w") as f:
        f.write(report)

    logging.info("Incident report written to %s (risk=%s)", out_path, risk_score)
    print(report)
    print(f"\nSaved to {out_path}")


if __name__ == "__main__":
    main()
