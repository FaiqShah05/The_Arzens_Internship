# THE ARZENS Threat Intelligence Enricher

A small command-line tool that checks IPs, domains, file hashes, and URLs
against VirusTotal, AbuseIPDB, and AlienVault OTX, and gives you back a
combined clean/suspicious/malicious verdict. Built for Assignment 4 of the
Beginner Track (AI, Automation & Security Engineering) at The Arzens.

## What's in here

| File | Purpose |
|---|---|
| `threat_intel_tool.py` | Core enrichment tool (Task 2) |
| `config.yaml` | API key config template |
| `.env.example` | Alternative way to store keys as env vars |
| `sample_indicators.txt` | 10 test indicators (IPs, domains, hashes) |
| `sample_output.json/.csv/.txt` | Example outputs from a sample run |
| `alert_enricher.py` | Single-alert enrichment workflow (Task 3) |
| `bulk_analyzer.py` | Bulk CSV enrichment workflow (Task 3) |
| `sample_alert.json` | Test alert for `alert_enricher.py` |
| `sample_indicators_bulk.csv` | 52 test indicators for `bulk_analyzer.py` |
| `WORKFLOWS.md` | Explains what each Task 3 workflow does |
| `research/` | Task 1 research note (docx + pdf) |

## Setup

1. Install dependencies:
   ```bash
   pip install requests pyyaml python-dotenv colorama
   ```

2. Get free API keys:
   - VirusTotal: sign up at virustotal.com, then Profile -> API key
   - AbuseIPDB: sign up at abuseipdb.com, then Account -> API
   - AlienVault OTX: sign up at otx.alienvault.com, then Settings -> API Integration

3. Put your keys in `config.yaml` (copy it and fill in the placeholders), or
   copy `.env.example` to `.env` and fill those in instead. Either way,
   **never commit real keys to git** — `config.yaml` and `.env` are meant to
   stay local.

## Usage

Single indicator:
```bash
python threat_intel_tool.py --ip 185.220.101.42
```

From a file:
```bash
python threat_intel_tool.py --input-file sample_indicators.txt --json-out results.json --csv-out results.csv
```

Interactive mode:
```bash
python threat_intel_tool.py --interactive
```

Alert enrichment pipeline:
```bash
python alert_enricher.py --alert sample_alert.json
```

Bulk analysis:
```bash
python bulk_analyzer.py --input-csv sample_indicators_bulk.csv
```

## Notes on the free-tier limits

VirusTotal's public API is limited to 4 requests/minute, so the tool sleeps
15 seconds between VT calls by default (see `vt_delay_seconds` in
`config.yaml`). AbuseIPDB free tier gives 1,000 checks/day, and OTX has no
meaningful rate limit once you're registered — details are all covered in
the Task 1 research note.

Results are cached in `cache.json` so re-running the tool on the same
indicator doesn't burn API quota. Delete that file (or pass `--no-cache`) if
you want a fresh lookup.

## AI Assistance Note

I used Claude (Anthropic) to help scaffold this project — structuring the
API integration functions, the retry/rate-limit logic, and the risk-scoring
approach in `alert_enricher.py`. I reviewed and adjusted the generated code
myself and tested it against the sample data included here.
