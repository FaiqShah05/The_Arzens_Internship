#!/usr/bin/env python3
"""
Bulk Indicator Analysis
Reads a CSV of indicators (indicator, type, source), enriches each one with
rate limiting, and produces a summary + detailed CSV report.

Author: Faiq Shah
"""

import argparse
import csv
import logging
import time
from collections import Counter
from datetime import datetime, timezone

from threat_intel_tool import load_config, load_cache, save_cache, enrich_indicator

logging.basicConfig(
    filename="workflow.log",
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)


def read_indicators(path):
    rows = []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row.get("indicator"):
                rows.append(row)
    return rows


def analyze(rows, config, cache, delay):
    records = []
    for i, row in enumerate(rows, start=1):
        indicator = row["indicator"].strip()
        try:
            record = enrich_indicator(indicator, config, cache)
            record["source"] = row.get("source", "unknown")
            records.append(record)
            print(f"[{i}/{len(rows)}] {indicator} -> {record.get('overall_verdict', 'ERROR')}")
        except Exception as e:
            logging.error("Failed on %s: %s", indicator, e)
            print(f"[{i}/{len(rows)}] {indicator} -> FAILED ({e})")
            continue
        if i < len(rows):
            time.sleep(delay)
    return records


def summarize(records):
    verdicts = Counter(r.get("overall_verdict", "UNKNOWN") for r in records)
    categories = Counter()
    reported = Counter()
    for r in records:
        vt = r.get("results", {}).get("virustotal", {})
        for cat in vt.get("categories", []) or []:
            categories[cat] += 1
        abuse = r.get("results", {}).get("abuseipdb", {})
        if abuse.get("total_reports"):
            reported[r["indicator"]] = abuse["total_reports"]

    return {
        "total": len(records),
        "verdicts": dict(verdicts),
        "top_categories": categories.most_common(5),
        "most_reported": reported.most_common(5),
    }


def write_csv(records, path):
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["indicator", "type", "source", "overall_verdict", "vt_detection", "abuseipdb_score", "otx_pulses"])
        for r in records:
            res = r.get("results", {})
            writer.writerow([
                r.get("indicator"),
                r.get("type"),
                r.get("source", "unknown"),
                r.get("overall_verdict"),
                res.get("virustotal", {}).get("detection_ratio", "n/a"),
                res.get("abuseipdb", {}).get("confidence_score", "n/a"),
                res.get("otx", {}).get("pulse_count", "n/a"),
            ])


def write_summary_html(summary, path):
    verdict_rows = "".join(
        f"<tr><td>{v}</td><td>{c}</td></tr>" for v, c in summary["verdicts"].items()
    )
    category_rows = "".join(
        f"<tr><td>{cat}</td><td>{count}</td></tr>" for cat, count in summary["top_categories"]
    )
    html = f"""<html>
<head><title>Bulk Analysis Summary</title></head>
<body>
<h1>THE ARZENS - Bulk Indicator Analysis</h1>
<p>Generated: {datetime.now(timezone.utc).isoformat()}</p>
<p>Total indicators processed: {summary['total']}</p>
<h2>Verdict Breakdown</h2>
<table border="1" cellpadding="6"><tr><th>Verdict</th><th>Count</th></tr>{verdict_rows}</table>
<h2>Top Threat Categories</h2>
<table border="1" cellpadding="6"><tr><th>Category</th><th>Count</th></tr>{category_rows}</table>
</body>
</html>"""
    with open(path, "w") as f:
        f.write(html)


def main():
    parser = argparse.ArgumentParser(description="Bulk-enrich indicators from a CSV file")
    parser.add_argument("--input-csv", required=True)
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument("--delay", type=float, default=15, help="Seconds to sleep between indicators")
    parser.add_argument("--csv-out", default="bulk_results.csv")
    parser.add_argument("--html-out", default="bulk_summary.html")
    args = parser.parse_args()

    rows = read_indicators(args.input_csv)
    if not rows:
        print("No indicators found in the input CSV.")
        return

    config = load_config(args.config)
    cache = load_cache()

    records = analyze(rows, config, cache, args.delay)
    save_cache(cache)

    summary = summarize(records)
    write_csv(records, args.csv_out)
    write_summary_html(summary, args.html_out)

    print("\n--- Summary ---")
    print(f"Total processed: {summary['total']}")
    print(f"Verdicts: {summary['verdicts']}")
    print(f"Detailed results: {args.csv_out}")
    print(f"HTML summary: {args.html_out}")


if __name__ == "__main__":
    main()
