# Automation Workflows

## Workflow 1: Alert Enrichment Pipeline (`alert_enricher.py`)

**Scenario:** A SOC alert fires with a single suspicious indicator, and
someone needs a full incident report fast instead of manually checking three
different websites.

**What it does:**
1. Reads an alert JSON file (`timestamp`, `alert_type`, `indicator`,
   `indicator_type`, `severity`, `source`).
2. Calls into `threat_intel_tool.py`'s `enrich_indicator()` to query
   VirusTotal, AbuseIPDB, and OTX for that indicator.
3. Runs a simple weighted risk-scoring algorithm (see below) to turn three
   separate verdicts into a single 0-100 number.
4. Picks a recommended action based on that score and writes a full incident
   report to `incidents/INC-<timestamp>.txt`.
5. Logs everything (what was queried, when, and the resulting risk score) to
   `workflow.log` for an audit trail.

**Risk scoring algorithm:** starts from a base score set by the alert's
stated severity (low=10, medium=30, high=50, critical=70), then adds:
- up to 20 points based on the VirusTotal detection ratio
- confidence_score * 0.2 from AbuseIPDB (so a 100/100 confidence adds 20)
- up to 10 points based on OTX pulse count

The total is capped at 100. Anything 80+ is CRITICAL and gets an immediate
block recommendation; 50-79 is HIGH (monitor + investigate); 20-49 is MEDIUM
(low-priority monitor); below 20 is LOW (no action).

Run it:
```bash
python alert_enricher.py --alert sample_alert.json
```

## Workflow 2: Bulk Indicator Analysis (`bulk_analyzer.py`)

**Scenario:** The threat intel team hands over a CSV of 50+ indicators
collected over the week and wants a quick "what's actually bad in here"
summary instead of checking each one by hand.

**What it does:**
1. Reads indicators from a CSV (`indicator`, `type`, `source` columns).
2. Enriches each one through the same shared enrichment function used by
   the core tool, sleeping between calls (`--delay`, default 15s) to respect
   the VirusTotal rate limit.
3. Builds summary statistics: total processed, verdict breakdown
   (clean/suspicious/malicious counts), top threat categories seen, and the
   most-reported indicators.
4. Writes the full per-indicator results to a CSV (`bulk_results.csv`) and a
   readable HTML summary (`bulk_summary.html`).
5. If a single indicator's lookup fails, the script logs it and moves on to
   the next one instead of crashing the whole batch.

Run it:
```bash
python bulk_analyzer.py --input-csv sample_indicators_bulk.csv
```

## Workflow 3: Scheduled Monitoring — not implemented

This was listed as a bonus item in the assignment (continuous hourly
monitoring of a watchlist using the `schedule` library, with change
detection and email/webhook alerts). I focused my time on getting Workflows
1 and 2 solid first and didn't get to this one for this submission.

## Design choices

- Both workflows import from `threat_intel_tool.py` rather than duplicating
  the API-calling code, so there's one place that knows how to talk to each
  platform.
- Config is loaded from `config.yaml`/`.env`, nothing is hardcoded.
- `cache.json` is shared across the core tool and both workflows, so running
  `bulk_analyzer.py` after already checking an indicator with
  `threat_intel_tool.py` won't waste API calls on it again.
- Every workflow logs to `workflow.log` so there's a record of what ran and
  when, separate from the console output.
